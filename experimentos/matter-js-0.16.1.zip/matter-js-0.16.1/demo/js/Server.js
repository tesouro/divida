// bundle entry point for the development server
Example = require('../../examples/index.js');
module.exports = require('../../src/module/main.js');
